import javax.swing.*;
import java.awt.*;

public class GradientPanel extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Crea un gradiente verticale dal blu al ciano
        GradientPaint gradient = new GradientPaint(
                0, 0, Color.BLUE,  // Colore superiore
                0,getHeight() , Color.CYAN  // Colore inferiore
        );

        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }
}