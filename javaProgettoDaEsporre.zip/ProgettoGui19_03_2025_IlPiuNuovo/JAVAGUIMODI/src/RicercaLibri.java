import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RicercaLibri {

    public RicercaLibri(JFrame f) {

        // Crea il frame (finestra)
        JFrame frame = new JFrame("Inserimento del libro");
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());


        // Crea un pannello per contenere i campi di testo e il menù a tendina
        GradientPanel panel = new GradientPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JButton titolo = new JButton("Titolo");
        titolo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titolo.setMaximumSize(new Dimension(350, 40));


        JButton autore = new JButton("Autore");
        autore.setAlignmentX(Component.CENTER_ALIGNMENT);
        autore.setMaximumSize(new Dimension(350, 40));


        JButton casa = new JButton("Casa Editrice");
        casa.setAlignmentX(Component.CENTER_ALIGNMENT);
        casa.setMaximumSize(new Dimension(350, 40));


        JButton periodo = new JButton("Periodo");
        periodo.setAlignmentX(Component.CENTER_ALIGNMENT);
        periodo.setMaximumSize(new Dimension(350, 40));

        JButton anno = new JButton("Anno");
        anno.setAlignmentX(Component.CENTER_ALIGNMENT);
        anno.setMaximumSize(new Dimension(350, 40));


        JButton genere = new JButton("Genere");
        genere.setAlignmentX(Component.CENTER_ALIGNMENT);
        genere.setMaximumSize(new Dimension(350, 40));

        panel.add(Box.createVerticalStrut(15));

        panel.add(titolo);
        panel.add(Box.createVerticalStrut(15));

        panel.add(autore);
        panel.add(Box.createVerticalStrut(15));

        panel.add(casa);
        panel.add(Box.createVerticalStrut(15));

        panel.add(anno);
        panel.add(Box.createVerticalStrut(15));

        panel.add(periodo);
        panel.add(Box.createVerticalStrut(15));

        panel.add(genere);
        panel.add(Box.createVerticalStrut(15));

        frame.add(panel, BorderLayout.CENTER);

        titolo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci un titolo");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <=4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });
        autore.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci un autore");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <= 4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });
        casa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci una casa editrice");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <= 4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });
        anno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci un anno");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <= 4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });
        periodo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Chiedi la data di inizio e fine
                String dataInizio = JOptionPane.showInputDialog("Inserisci data iniziale (yyyy-MM-dd)");
                String dataFine = JOptionPane.showInputDialog("Inserisci data finale (yyyy-MM-dd)");

                // Verifica che le date non siano vuote
                if (dataInizio == null || dataFine == null || dataInizio.trim().isEmpty() || dataFine.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Le date non possono essere vuote.");
                    return;
                }

                try {
                    // Converti le stringhe delle date in oggetti Date
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    sdf.setLenient(false);  // Impedisce la conversione di date non valide, come 2025-02-30

                    Date startDate = sdf.parse(dataInizio);
                    Date endDate = sdf.parse(dataFine);

                    // Verifica che la data di inizio non sia successiva alla data di fine
                    if (startDate.after(endDate)) {
                        JOptionPane.showMessageDialog(null, "La data di inizio non può essere successiva alla data di fine.");
                        return;
                    }

                    String libri = "";
                    try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                        String riga;
                        String libro = "";
                        boolean inLibro = false;

                        while ((riga = file.readLine()) != null) {
                            if (riga.trim().equals("-------------------")) {
                                // Se siamo alla fine di un libro, controlliamo se la data è nel range
                                if (!libro.isEmpty()) {
                                    String[] datiLibro = libro.split("\n");
                                    String dataLibro = datiLibro[3];  // la data si trova sulla quarta riga
                                    try {
                                        Date bookDate = sdf.parse(dataLibro);

                                        // Se la data del libro è compresa nel range
                                        if ((bookDate.after(startDate) || bookDate.equals(startDate)) &&
                                                (bookDate.before(endDate) || bookDate.equals(endDate))) {
                                            libri = libri + libro;
                                        }
                                    } catch (ParseException ex) {
                                        System.out.println("Errore nel parsing della data del libro: " + dataLibro);
                                    }
                                }

                                // Resetta la variabile libro per il prossimo libro
                                libro = "";
                            } else {
                                libro += riga + "\n";
                            }
                        }

                    } catch (IOException n) {
                        // Gestisci eventuali errori di lettura del file
                        JOptionPane.showMessageDialog(null, "Errore nella lettura del file");
                    }

                    // Mostra i libri che rientrano nel periodo selezionato
                    new messaggio(libri);

                } catch (ParseException ex) {
                    // Gestisci errori nel parsing delle date
                    JOptionPane.showMessageDialog(null, "Formato data non valido. Usa il formato yyyy-MM-dd.");
                }
            }
        });




        genere.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci un genere");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <= 4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });



        frame.setVisible(true);
        frame.setSize(500, 300);
        frame.setLocation(668,157);
    }

}
