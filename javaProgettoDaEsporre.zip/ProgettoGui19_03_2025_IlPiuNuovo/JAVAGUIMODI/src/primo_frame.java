import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class primo_frame extends javax.swing.JFrame {

    private JTextField field;
    private JButton bottoneInserisci;
    private JButton bottoneElimina;
    private JButton bottoneRicerca;
    private JButton bottoneModifica;
    private TextAreaPanel area;

    public primo_frame() {
        JFrame frame = new JFrame();

        // Impostazioni layout per il JFrame principale
        setLayout(new BorderLayout(10, 10));

        // Creazione dei componenti
        area = new TextAreaPanel();
        JButton bottoneInserisci = new JButton("Inserisci un libro ");
        JButton bottoneElimina = new JButton("Elimina un libro ");
        JButton bottoneRicerca = new JButton("Ricerca un libro ");
        JButton bottoneModifica = new JButton("Modifica un libro ");
        JTextField field = new JTextField();

        // Rendere la TextArea non modificabile
        area.setEditable(false);

        // Lettura del file e popolamento dell'area
        leggiFile();

        // Pannello dei bottoni con FlowLayout centrato
        GradientPanel panelB = new GradientPanel();
        panelB.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelB.add(bottoneRicerca);
        panelB.add(bottoneInserisci);
        panelB.add(bottoneElimina);
        panelB.add(bottoneModifica);
        JScrollPane scrollPane = new JScrollPane(area);
        // Aggiunta dell'area di testo sopra i bottoni
        frame.add(scrollPane, BorderLayout.CENTER);

        // Aggiunta del pannello dei bottoni in basso al centro
        frame.add(panelB, BorderLayout.SOUTH);

        // Azioni dei bottoni
        bottoneInserisci.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new inserisciLibro(frame);
                dispose();
            }
        });


        bottoneElimina.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new eliminaFile(frame);
                dispose();
            }
        });
        bottoneRicerca.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            new RicercaLibri(frame);

            }
        });
        bottoneModifica.addActionListener(new ActionListener() {
            @Override public void actionPerformed(ActionEvent e) {
           new ModificaLibro(frame);
            dispose();
        }});

        // Impostazioni finestra
        frame.setSize(800, 500);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Metodo per leggere il file e mostrare il contenuto nell'area
    private void leggiFile() {
        try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
            String riga;
            while ((riga = file.readLine()) != null) {
                area.appenditesto(riga);
                area.appenditesto("\n");
            }
        } catch (IOException e) {
            System.out.println("Errore riscontrato nella lettura di un file");
        }
    }
}
