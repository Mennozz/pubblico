import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class login extends javax.swing.JFrame {
    private int cont=0;
    public login(JFrame f)
    {

        JFrame frame = new JFrame("Accedi");

        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());


        GradientPanel panel = new GradientPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));


        JLabel username = new JLabel("Username: ");
        username.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel password = new JLabel("Password: ");
        password.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton login = new JButton("Accedi");
        login.setAlignmentX(Component.CENTER_ALIGNMENT);

        JToggleButton toggleButton = new JToggleButton("👁️");
        toggleButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        

        JTextField usernameText = new JTextField();
        usernameText.setMaximumSize(new Dimension(300, 30));

        JPasswordField passwordText = new JPasswordField();
        passwordText.setMaximumSize(new Dimension(300, 30));

        // Crea un toggle button (l'icona dell'occhiolino)


        // Aggiungi un listener per il toggle button





        panel.add(Box.createVerticalStrut(35));
        panel.add(username);
        panel.add(usernameText);
        panel.add(Box.createVerticalStrut(40));
        panel.add(password);
        panel.add(passwordText);
        panel.add(Box.createVerticalStrut(5));
        panel.add(toggleButton);
        frame.add(login, BorderLayout.SOUTH);
        frame.add(panel, BorderLayout.CENTER);


        toggleButton.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    // Mostra la password in chiaro
                    passwordText.setEchoChar((char) 0); // Caratteri visibili
                } else {
                    // Nasconde la password con un asterisco
                    passwordText.setEchoChar('•'); // Caratteri mascherati
                }
            }
        });


        login.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String riga="";
                boolean Giusto = false;
                String username = usernameText.getText();
                String password =String.valueOf(passwordText.getPassword());
                if (!(username.isEmpty() || password.isEmpty()))
                {
                    try
                    {
                        BufferedReader fr = new BufferedReader(new FileReader("Login.txt"));
                        riga=fr.readLine();
                        while (riga != null)
                        {
                            if(username.equals(riga)) {
                                riga= fr.readLine();
                                if (password.equals(riga)) {
                                    JOptionPane.showMessageDialog(frame, "Accesso effettuato correttamente");
                                    Giusto = true;
                                    frame.dispose();
                                    f.dispose();
                                    new primo_frame();

                                }

                            }

                            riga=fr.readLine();
                        }
                        if(!Giusto) {
                            if(cont ==0) {
                                JOptionPane.showMessageDialog(frame, "Qualcosa non va, riprova");

                            }

                            if(cont ==1)
                            {
                                JOptionPane.showMessageDialog(frame, "Ultimo tentativo");
                            }
                            if(cont ==2)
                            {
                                JOptionPane.showMessageDialog(frame, "Troppi errori ciao :)");
                                frame.dispose();

                            }
                            cont =cont+1;

                        }


                    }

                    catch (IOException i)
                    {
                        JOptionPane.showMessageDialog(frame, "Account non registrato");
                    }
                }
                else{
                    JOptionPane.showMessageDialog(frame, "Devi scrivere in tutti i campi");
                }


            }
        });


        frame.addWindowListener(new WindowAdapter() {
            @Override

            public void windowClosing(WindowEvent e) {
                // Chiamare dispose() quando la finestra sta per essere chiusa
                frame.dispose();
                f.setVisible(true);

            }
        });




        frame.setSize(500, 300);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);
    }

}

