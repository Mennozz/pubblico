import javax.swing.*;
import java.awt.*;

public class TextAreaPanel extends JPanel{
    private JTextArea area;

    public TextAreaPanel(){
        area = new JTextArea();
        setLayout(new BorderLayout());
        add(area, BorderLayout.CENTER);

    }
    public void appenditesto(String testo)
    {
        area.append(testo);
    }


    public void setEditable(boolean b) {
        area.setEditable(b);
    }
}
