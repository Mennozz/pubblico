import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RicercaLibri {

    public RicercaLibri(JFrame f) {
        // Crea il frame (finestra)
        JFrame frame = new JFrame("Inserimento del libro");
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        ImageIcon icon = new ImageIcon(tutorial_frame.class.getResource("/logo.jpg"));
        frame.setIconImage(icon.getImage());

        // Crea un pannello per contenere i campi di testo e il menù a tendina
        GradientPanel panel = new GradientPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JButton titolo = new JButton("Titolo");
        titolo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titolo.setMaximumSize(new Dimension(350, 40));

        JButton autore = new JButton("Autore");
        autore.setAlignmentX(Component.CENTER_ALIGNMENT);
        autore.setMaximumSize(new Dimension(350, 40));

        JButton casa = new JButton("Casa Editrice");
        casa.setAlignmentX(Component.CENTER_ALIGNMENT);
        casa.setMaximumSize(new Dimension(350, 40));

        JButton periodo = new JButton("Periodo");
        periodo.setAlignmentX(Component.CENTER_ALIGNMENT);
        periodo.setMaximumSize(new Dimension(350, 40));

        JButton anno = new JButton("Data");
        anno.setAlignmentX(Component.CENTER_ALIGNMENT);
        anno.setMaximumSize(new Dimension(350, 40));

        JButton genere = new JButton("Genere");
        genere.setAlignmentX(Component.CENTER_ALIGNMENT);
        genere.setMaximumSize(new Dimension(350, 40));

        panel.add(Box.createVerticalStrut(15));
        panel.add(titolo);
        panel.add(Box.createVerticalStrut(15));
        panel.add(autore);
        panel.add(Box.createVerticalStrut(15));
        panel.add(casa);
        panel.add(Box.createVerticalStrut(15));
        panel.add(anno);
        panel.add(Box.createVerticalStrut(15));
        panel.add(periodo);
        panel.add(Box.createVerticalStrut(15));
        panel.add(genere);
        panel.add(Box.createVerticalStrut(15));

        frame.add(panel, BorderLayout.CENTER);

        // ActionListener per Titolo
        titolo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci un titolo");
                String libri = cercaLibri("Titolo", tit);
                new messaggio(libri);
            }
        });

        // ActionListener per Autore
        autore.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String autoreSearch = JOptionPane.showInputDialog("Inserisci un autore");
                String libri = cercaLibri("Autore", autoreSearch);
                new messaggio(libri);
            }
        });

        // ActionListener per Casa Editrice
        casa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String casaSearch = JOptionPane.showInputDialog("Inserisci una casa editrice");
                String libri = cercaLibri("Casa Editrice", casaSearch);
                new messaggio(libri);
            }
        });

        // ActionListener per Data
        anno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Chiedi all'utente di inserire una data
                String dataInput = JOptionPane.showInputDialog("Inserisci una data (Formato: YYYY-MM-DD)");

                // Controlla se l'input della data è valido
                try {
                    // Proviamo a parsare la data
                    java.time.LocalDate data = java.time.LocalDate.parse(dataInput);

                    // Estrai l'anno dalla data
                    int anno = data.getYear();
                    int annoCorrente = java.time.LocalDate.now().getYear(); // Ottieni l'anno corrente

                    // Verifica che l'anno inserito sia valido e non maggiore dell'anno corrente
                    if (anno < 1000 || anno > annoCorrente) {
                        // Se l'anno non è valido, mostra un messaggio di errore
                        JOptionPane.showMessageDialog(null, "Inserisci un anno valido (tra 1000 e l'anno corrente).", "Errore", JOptionPane.ERROR_MESSAGE);
                    } else {
                        // Se l'anno è valido, esegui la ricerca
                        String libri = cercaLibri("Anno", dataInput);
                        new messaggio(libri);
                    }
                } catch (java.time.format.DateTimeParseException ex) {
                    // Se la data non è nel formato corretto
                    JOptionPane.showMessageDialog(null, "Formato data non valido. Usa il formato: YYYY-MM-DD.", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        });



        // ActionListener per Periodo (Data)
        periodo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dataInizio = JOptionPane.showInputDialog("Inserisci data iniziale (yyyy-MM-dd)");
                String dataFine = JOptionPane.showInputDialog("Inserisci data finale (yyyy-MM-dd)");
                String libri = searchBooksByDate(dataInizio, dataFine);
                new messaggio(libri);
            }
        });

        // ActionListener per Genere
        genere.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String genereSearch = JOptionPane.showInputDialog("Inserisci un genere");
                String libri = cercaLibri("Genere", genereSearch);
                new messaggio(libri);
            }
        });

        frame.setVisible(true);
        frame.setSize(500, 300);
        frame.setLocation(668, 157);
    }

    // Funzione che effettua la ricerca nei libri in base al tipo di ricerca (Titolo, Autore, Casa, Genere, Anno)
    private String cercaLibri(String tipoRicerca, String valoreRicerca) {
        // Costruisce una stringa che conterrà tutti i libri trovati
        StringBuilder libri = new StringBuilder();

        try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
            String riga;
            String libro = "";  // Variabile che conterrà tutte le righe di un libro

            // Legge il file riga per riga
            while ((riga = file.readLine()) != null) {
                // Verifica se la riga è la separazione tra i libri (-------------------)
                if (riga.trim().equals("-------------------")) {
                    // Quando troviamo una riga che separa i libri, significa che un libro è stato letto interamente
                    String[] datiLibro = libro.split("\n");  // Divide il libro in base alle righe

                    // Variabile per memorizzare il valore del campo che vogliamo cercare
                    String valoreCampo = "";

                    // A seconda del tipo di ricerca (Titolo, Autore, Casa Editrice, etc.), estraiamo il valore corrispondente dal libro
                    switch (tipoRicerca) {
                        case "Titolo":
                            valoreCampo = datiLibro[0];  // Titolo è sulla prima riga
                            break;
                        case "Autore":
                            valoreCampo = datiLibro[1];  // Autore è sulla seconda riga
                            break;
                        case "Casa Editrice":
                            valoreCampo = datiLibro[2];  // Casa Editrice è sulla terza riga
                            break;
                        case "Anno":
                            valoreCampo = datiLibro[3];  // Anno è sulla quarta riga
                            break;
                        case "Genere":
                            valoreCampo = datiLibro[4];  // Genere è sulla quinta riga
                            break;
                    }

                    // Se il valore del campo trovato corrisponde esattamente a quello che stiamo cercando (valoreRicerca)
                    if (valoreCampo != null && valoreCampo.equals(valoreRicerca)) {
                        libri.append(libro).append("\n");  // Aggiungi il libro alla lista dei risultati
                    }

                    // Resetta la variabile libro per prepararsi a leggere il prossimo libro
                    libro = "";
                } else {
                    // Se la riga non è la separazione, la aggiungiamo al libro
                    libro += riga + "\n";
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Errore nella lettura del file.");
        }

        // Ritorna la stringa contenente tutti i libri trovati
        return libri.toString();
    }


    // Funzione che effettua la ricerca per intervallo di date
    private String searchBooksByDate(String dataInizio, String dataFine) {
        StringBuilder libri = new StringBuilder();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date startDate = sdf.parse(dataInizio);
            Date endDate = sdf.parse(dataFine);

            try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                String riga;
                String libro = "";
                while ((riga = file.readLine()) != null) {
                    if (riga.trim().equals("-------------------")) {
                        String[] datiLibro = libro.split("\n");
                        String dataLibro = datiLibro[3];  // La data è sulla quarta riga

                        Date bookDate = sdf.parse(dataLibro);
                        if ((bookDate.after(startDate) || bookDate.equals(startDate)) && (bookDate.before(endDate) || bookDate.equals(endDate))) {
                            libri.append(libro).append("\n");
                        }

                        libro = "";  // Resetta per il prossimo libro
                    } else {
                        libro += riga + "\n";
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Errore nella lettura del file.");
            }
        } catch (ParseException ex) {
            //JOptionPane.showMessageDialog(null, "Formato data non valido. Usa il formato yyyy-MM-dd.");
        }
        return libri.toString();
    }
}
