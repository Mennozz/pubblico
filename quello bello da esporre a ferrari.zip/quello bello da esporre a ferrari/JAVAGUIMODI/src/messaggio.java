import javax.swing.*;
import java.awt.*;

public class messaggio extends JFrame {

    public messaggio(String mess) {
        // Configurazione della finestra
        setTitle("Inserimento del libro");
        setSize(400, 300);
        setLayout(new BorderLayout());

        ImageIcon icon = new ImageIcon(tutorial_frame.class.getResource("/logo.jpg"));
        setIconImage(icon.getImage());

        // Creazione della JTextArea
        JTextArea text = new JTextArea();
        text.setEditable(false);
        text.setText(mess);

        // Aggiunta della JTextArea dentro uno JScrollPane
        JScrollPane scrollPane = new JScrollPane(text);
        add(scrollPane, BorderLayout.CENTER);

        // Impostazione della posizione e visibilità
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
