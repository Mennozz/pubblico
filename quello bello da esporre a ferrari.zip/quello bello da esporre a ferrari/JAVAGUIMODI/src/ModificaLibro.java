import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Calendar;

public class ModificaLibro extends javax.swing.JFrame {//NON FUNZIONA SE UN PARAMETRO é UGUALE A QUELLO DEL TITOLO
    private JComboBox<String> comboBoxE;
    private String sostitutivo="";
    private String dataTrovata,GenereTrovato;
    private boolean presi=true;//controlla presiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii
    private JButton buttonM;
    private ArrayList<String> libreria = new ArrayList<>();
    public ModificaLibro(JFrame f) {

        JFrame frame = new JFrame("Modifica Libro");
        ImageIcon icon = new ImageIcon(tutorial_frame.class.getResource("/logo.jpg"));
        frame.setIconImage(icon.getImage());

        frame.setSize(600, 500);
        //frame.setLayout(new BorderLayout(10,10));
        frame.setBackground(Color.BLUE);


        GradientPanel1 panels = new GradientPanel1();
        panels.setLayout(new BoxLayout(panels, BoxLayout.Y_AXIS));  // Layout verticale
        panels.setAlignmentX(Component.CENTER_ALIGNMENT);  // Centra il pannello
        panels.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));  // Aggiungi margini al pannello

        // Aggiungi etichetta sopra il menù a tendina
        JLabel label = new JLabel("Seleziona il libro da modificare:");
        label.setAlignmentX(Component.CENTER_ALIGNMENT);  // Centra l'etichetta
        panels.add(label);
        panels.add(Box.createVerticalStrut(30)); // Spazio tra etichetta e comboBox

        // Crea il menù a tendina per la selezione del libro
        comboBoxE = new JComboBox<>();
        comboBoxE.setPreferredSize(new Dimension(100, 50));  // Imposta la dimensione compatta

        panels.add(comboBoxE);
        panels.add(Box.createVerticalStrut(60));  // Spazio tra il comboBox e il bottone

        // Crea il bottone per l'eliminazione
        buttonM = new JButton("Modifica");
        buttonM.setAlignmentX(Component.CENTER_ALIGNMENT);  // Centra il bottone


        // Aggiungi il pannello al centro della finestra


        // Lettura dei libri dal file "Libreria.txt" e popolamento del comboBox
        try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
            String riga;
            int count = 0;
            String titolo = "";
            while ((riga = file.readLine()) != null) {
                if (count == 0) {
                    titolo = riga;  // La prima riga è il titolo del libro
                    comboBoxE.addItem(titolo);  // Aggiungi il titolo al comboBox
                }
                // Se la riga è vuota (indicando separazione tra libri), resettiamo count
                if (riga.equals("-------------------")) {
                    count = -1;
                }
                count++;
            }
            file.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Errore durante la lettura del file.");
        }



        // Crea un pannello per contenere i campi di testo e il menù a tendina
        GradientPanel panel = new GradientPanel();
        panel.setLayout(new GridLayout(6, 2)); // 6 righe e 2 colonne (campo + titolo)
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // Crea 4 coppie di etichetta (titolo) e campo di testo
        JLabel label1 = new JLabel("Titolo:");
        JTextField field1 = new JTextField();

        JLabel label2 = new JLabel("Autore:");
        JTextField field2 = new JTextField();

        JLabel label3 = new JLabel("Casa Editrice:");
        JTextField field3 = new JTextField();

        JLabel label4 = new JLabel("Data:");
        JButton field4 = new JButton("cliccami");


        // Etichetta e menù a tendina (JComboBox)
        JLabel label5 = new JLabel("Genere:");
        JComboBox<String> comboBoxG = new JComboBox<>(new String[]{
                "Romanzo", "Thriller", "Fantasy", "Sci-Fi", "Storico", "Giallo", "Horror", "Biografia",
                "Autobiografia", "Classico", "Poesia", "Saggio", "Dramma", "Commedia", "Filosofia", "Psicologia"
        });

        // Aggiungi le etichette, i campi di testo e il menù a tendina al pannello
        panel.add(label1);
        panel.add(field1);
        panel.add(label2);
        panel.add(field2);
        panel.add(label3);
        panel.add(field3);
        panel.add(label4);
        panel.add(field4);
        panel.add(label5);
        panel.add(comboBoxG);

        // Crea un bottone


        // Aggiungi l'azione al bottone
        buttonM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // Recupera i valori dai campi di testo
                String titolo = field1.getText();
                String autore = field2.getText();
                String casaEd = field3.getText();
                String annoString;
                if(data.finalDate!=null){
                    annoString= data.finalDate;
                }
                else{
                    annoString=dataTrovata;
                }

                String selectedOption;
                // Recupera l'opzione selezionata dal menù a tendina
                if((String) comboBoxG.getSelectedItem()!=null){
                    selectedOption = (String) comboBoxG.getSelectedItem();
                }
                else{
                    selectedOption=GenereTrovato;
                }


                // Ottieni l'anno corrente


                if (!titolo.isEmpty() && !autore.isEmpty() && !casaEd.isEmpty() && !annoString.isEmpty()) {
                    try {
                        // Verifica se l'anno inserito è valido
                        LocalDate data = LocalDate.parse(annoString);

                        // Controlla se l'anno è minore o uguale all'anno corrente
                        if (data.isAfter(LocalDate.now())) {
                            JOptionPane.showMessageDialog(frame, "L'anno inserito non può essere maggiore dell'anno corrente.");
                            return; // Esci senza fare nulla
                        }

                        // Scrivi il libro nel file

                        sostitutivo = titolo + "\n" + autore + "\n" + casaEd + "\n" + data + "\n" + selectedOption + "\n-------------------\n";
                        presi=true;

                    } catch (DateTimeParseException m) {
                        JOptionPane.showMessageDialog(frame, "L'anno deve essere un numero valido.");
                        presi = false;

                    }
                    if (presi == true) {
                        String titoloSelezionato = (String) comboBoxE.getSelectedItem();

                        if (titoloSelezionato != null) {
                            // Elimina il libro selezionato dal comboBox
                            try {
                                String libriDaSalvare = "";
                                BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"));
                                String riga;
                                while ((riga = file.readLine()) != null) {
                                    // Se la riga contiene il titolo da eliminare, saltalo
                                    if (riga.equals(titoloSelezionato)) {
                                        // Il libro è stato trovato, quindi lo saltiamo
                                        // Salta anche le 3 righe successive (autore, casa editrice, anno)
                                        file.readLine();
                                        file.readLine();
                                        file.readLine();
                                        file.readLine();
                                        file.readLine();
                                        libriDaSalvare = libriDaSalvare+sostitutivo;
                                    } else {
                                        // Aggiungi le righe che non sono state eliminate
                                        libriDaSalvare = libriDaSalvare + riga + "\n";
                                    }
                                }
                                file.close();

                                // Scrive i libri rimanenti nel file
                                FileWriter fw = new FileWriter("Libreria.txt", false);

                                fw.write(libriDaSalvare);

                                fw.close();

                                // Mostra messaggio di successo

                                frame.dispose();  // Chiudi la finestra di eliminazione
                                new primo_frame();
                                f.setVisible(false);// Riapri la finestra principale
                            } catch (IOException ex) {
                                JOptionPane.showMessageDialog(ModificaLibro.this, "Errore durante l'eliminazione del libro.");
                            }
                        } else {
                            JOptionPane.showMessageDialog(ModificaLibro.this, "Devi selezionare un libro da eliminare.");
                        }
                    }
                }
                else {
                    JOptionPane.showMessageDialog(frame, "Devi inserire tutti i campi\naltrimenti non verrà inserito il libro");
                }
            }

        });


        field4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new data();

            }});
        comboBoxE.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String TitoloSelezionato = comboBoxE.getSelectedItem().toString();
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"));) {
                    String riga;
                    while ((riga = file.readLine()) != null) {
                        // Se la riga contiene il titolo da eliminare, saltalo
                        if (riga.equals(TitoloSelezionato)) {
                            // Il libro è stato trovato, quindi lo saltiamo
                            // Salta anche le 3 righe successive (autore, casa editrice, anno)

                            field1.setText(riga);
                            riga = file.readLine();
                            field2.setText(riga);
                            riga = file.readLine();
                            field3.setText(riga);
                            riga = file.readLine();
                            field4.setText("Data: "+riga);
                            dataTrovata = riga;
                            riga = file.readLine();
                            comboBoxG.setSelectedItem(riga);
                            GenereTrovato = riga;
                        }
                    }
                    file.close();
                }
                catch (FileNotFoundException ex) {
                    throw new RuntimeException(ex);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(ModificaLibro.this, "Errore durante l'eliminazione del libro.");
                    throw new RuntimeException(ex);
                }
            }});




        // Azione per il bottone di eliminazione
        frame.add(panels,BorderLayout.NORTH);
        frame.add(panel,BorderLayout.CENTER);
        frame.add(buttonM,BorderLayout.SOUTH);
        frame.setVisible(true);
        frame.setBackground(Color.BLUE);
        frame.setLocation(568,157);

    }
    public class GradientPanel1  extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;

            // Crea un gradiente verticale dal blu al ciano
            GradientPaint gradient = new GradientPaint(
                    0, getHeight(), Color.BLUE,  // Colore superiore
                    0, 0, Color.CYAN  // Colore inferiore
            );

            g2d.setPaint(gradient);
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}