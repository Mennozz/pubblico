import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.file.Path;

import static java.nio.file.Files.exists;

public class tutorial_frame {
    public static void main(String[] args) {
        JFrame frame = new JFrame("La nostra prima finestra");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(200, 135);
        frame.setLayout(new BorderLayout());
        GradientPanel panel = new GradientPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JButton login = new JButton("login");
        login.setAlignmentX(Component.CENTER_ALIGNMENT);
        login.setMaximumSize(new Dimension(100, 100));

        JButton sing = new JButton("sing up");
        sing.setAlignmentX(Component.CENTER_ALIGNMENT);
        sing.setMaximumSize(new Dimension(100, 100));

        ImageIcon originalIcon = new ImageIcon("/logoGui.png");
        Image scaledImage = originalIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel label = new JLabel(scaledIcon);

        panel.add(Box.createVerticalStrut(15));
        panel.add(login);
        panel.add(Box.createVerticalStrut(15));
        panel.add(sing);
        panel.add(Box.createVerticalStrut(15));
        panel.add(label);
        frame.add(panel, BorderLayout.CENTER);

        login.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                new login(frame);
                frame.setVisible(false);
            }

        });
        sing.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                new create_account(frame);
                frame.setVisible(false);
            }
        });

        frame.setVisible(true);

        frame.setLocationRelativeTo(null);


    }


}

