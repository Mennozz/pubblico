import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class inserisciLibro extends javax.swing.JFrame {

    public inserisciLibro(JFrame f) {
        // Crea il frame (finestra)

        JFrame frame = new JFrame("Inserimento del libro");

        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());


        // Crea un pannello per contenere i campi di testo e il menù a tendina
        GradientPanel panel = new GradientPanel();
        panel.setLayout(new GridLayout(6, 2)); // 6 righe e 2 colonne (campo + titolo)
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // Crea 4 coppie di etichetta (titolo) e campo di testo
        JLabel label1 = new JLabel("Titolo:");
        JTextField field1 = new JTextField();

        JLabel label2 = new JLabel("Autore:");
        JTextField field2 = new JTextField();

        JLabel label3 = new JLabel("Casa Editrice:");
        JTextField field3 = new JTextField();

        JLabel label4 = new JLabel("Anno:");
        JButton field4 = new JButton("cliccami");


        // Etichetta e menù a tendina (JComboBox)
        JLabel label5 = new JLabel("Genere:");
        JComboBox<String> comboBox = new JComboBox<>(new String[]{
                "Romanzo", "Thriller", "Fantasy", "Sci-Fi", "Storico", "Giallo", "Horror", "Biografia",
                "Autobiografia", "Classico", "Poesia", "Saggio", "Dramma", "Commedia", "Filosofia", "Psicologia"
        });

        // Aggiungi le etichette, i campi di testo e il menù a tendina al pannello
        panel.add(label1);
        panel.add(field1);
        panel.add(label2);
        panel.add(field2);
        panel.add(label3);
        panel.add(field3);
        panel.add(label4);
        panel.add(field4);
        panel.add(label5);
        panel.add(comboBox);

        // Crea un bottone
        JButton button = new JButton("Prendi valori");

        // Aggiungi l'azione al bottone
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // Recupera i valori dai campi di testo
                String titolo = field1.getText();
                String autore = field2.getText();
                String casaEd = field3.getText();
                String annoString = data.finalDate;

                // Recupera l'opzione selezionata dal menù a tendina
                String selectedOption = (String) comboBox.getSelectedItem();

                // Ottieni l'anno corrente

                boolean fatto = true;
                if (!titolo.isEmpty() && !autore.isEmpty() && !casaEd.isEmpty() && !annoString.isEmpty()) {
                    try {
                        // Verifica se l'anno inserito è valido
                        LocalDate data = LocalDate.parse(annoString);

                        // Controlla se l'anno è minore o uguale all'anno corrente
                        if (data.isAfter(LocalDate.now())) {
                            JOptionPane.showMessageDialog(frame, "L'anno inserito non può essere maggiore dell'anno corrente.");
                            return; // Esci senza fare nulla
                        }

                        // Scrivi il libro nel file
                        FileWriter fw = new FileWriter("Libreria.txt", true);
                        fw.write(titolo + "\n" + autore + "\n" + casaEd + "\n" + data + "\n" + selectedOption + "\n-------------------\n");
                        fw.close();

                    } catch (IOException i) {
                        JOptionPane.showMessageDialog(frame, "Errore nell'inserimento del libro\nIl libro non verrà inserito nella libreria");
                    } catch (DateTimeParseException m) {
                        JOptionPane.showMessageDialog(frame, "L'anno deve essere un numero valido.");
                        fatto = false;
                    }

                    if(fatto == true)
                    {
                        frame.dispose();
                        new primo_frame();
                    }

                }
                else {
                    JOptionPane.showMessageDialog(frame, "Devi inserire tutti i campi\naltrimenti non verrà inserito il libro");
                }
            }
        });


        field4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new data();

            }});


        // Aggiungi il pannello e il bottone alla finestra
        frame.add(panel, BorderLayout.CENTER);
        frame.add(button, BorderLayout.SOUTH);

        // Rendi visibile la finestra
        frame.setVisible(true);
        frame.setSize(500, 300);
        frame.setLocation(668,157);

        setResizable(false);
    }
}
