import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

public class data {
    public static String finalDate;
    public data() {
        // Finestra principale
        JFrame frame = new JFrame("Calendario");
        frame.setSize(400, 450);
        frame.setLayout(new BorderLayout());

        // Pannello per selezionare mese e anno
        GradientPanel controlPanel = new GradientPanel();
        controlPanel.setLayout(new FlowLayout());

        // ComboBox per selezionare il mese
        String[] months = {"Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"};
        JComboBox<String> monthComboBox = new JComboBox<>(months);
        monthComboBox.setSelectedIndex(Calendar.getInstance().get(Calendar.MONTH));

        // ComboBox per selezionare l'anno
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        Integer[] years = new Integer[1026]; // Anni da 1000 a 2025
        for (int i = 0; i < 1026; i++) {
            years[i] = 1000 + i;
        }
        JComboBox<Integer> yearComboBox = new JComboBox<>(years);
        yearComboBox.setSelectedItem(currentYear);

        controlPanel.add(new JLabel("Mese:"));
        controlPanel.add(monthComboBox);
        controlPanel.add(new JLabel("Anno:"));
        controlPanel.add(yearComboBox);

        // Pannello per il calendario
        JPanel calendarPanel = new JPanel();
        calendarPanel.setLayout(new GridLayout(0, 7));

        // Aggiunta dei giorni della settimana
        String[] daysOfWeek = {"Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"};
        for (String day : daysOfWeek) {
            calendarPanel.add(new JLabel(day, SwingConstants.CENTER));
        }

        // Etichetta per mostrare la data selezionata
        JLabel selectedDateLabel = new JLabel("Data selezionata: ----/--/--", SwingConstants.CENTER);

        // Bottone per confermare la data selezionata
        JButton confirmButton = new JButton("Conferma Data");
        confirmButton.setEnabled(false);

        // Funzione per aggiornare il calendario
        final int[] selectedDay = {-1};
        ActionListener updateCalendar = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedMonth = monthComboBox.getSelectedIndex();
                int selectedYear = (Integer) yearComboBox.getSelectedItem();
                Calendar currentDate = Calendar.getInstance();
                currentDate.set(selectedYear, selectedMonth, 1);
                int firstDayOfMonth = currentDate.get(Calendar.DAY_OF_WEEK);
                int daysInMonth = currentDate.getActualMaximum(Calendar.DAY_OF_MONTH);

                calendarPanel.removeAll();
                for (String day : daysOfWeek) {
                    calendarPanel.add(new JLabel(day, SwingConstants.CENTER));
                }

                for (int i = 0; i < firstDayOfMonth - 1; i++) {
                    calendarPanel.add(new JLabel(""));
                }

                for (int day = 1; day <= daysInMonth; day++) {
                    JButton dayButton = new JButton(String.valueOf(day));
                    dayButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            selectedDay[0] = Integer.parseInt(dayButton.getText());
                            String formattedDate = String.format("%02d-%02d-%02d", selectedYear,selectedMonth + 1,selectedDay[0] );
                            selectedDateLabel.setText("Data selezionata: " + formattedDate);
                            confirmButton.setEnabled(true);
                        }
                    });
                    calendarPanel.add(dayButton);
                }

                calendarPanel.revalidate();
                calendarPanel.repaint();
            }
        };

        monthComboBox.addActionListener(updateCalendar);
        yearComboBox.addActionListener(updateCalendar);

        // Azione per il bottone di conferma
        confirmButton.addActionListener(e -> {
            if (selectedDay[0] != -1) {
                finalDate = selectedDateLabel.getText().replace("Data selezionata: ", "");

                frame.dispose();
            }
        });

        // Pannello inferiore
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(selectedDateLabel, BorderLayout.CENTER);
        bottomPanel.add(confirmButton, BorderLayout.SOUTH);

        frame.add(controlPanel, BorderLayout.NORTH);
        frame.add(calendarPanel, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
        updateCalendar.actionPerformed(null);
    }

    public data(String dat)
    {
        JFrame frame = new JFrame("Calendario");
        frame.setSize(400, 450);
        frame.setLayout(new BorderLayout());
        if(dat == "inizio")
        {
            JOptionPane.showMessageDialog(frame, "Scegli data inizio");
        }
        else
        {
            JOptionPane.showMessageDialog(frame, "Scegli data fine");
        }
        // Pannello per selezionare mese e anno
        GradientPanel controlPanel = new GradientPanel();
        controlPanel.setLayout(new FlowLayout());

        // ComboBox per selezionare il mese
        String[] months = {"Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"};
        JComboBox<String> monthComboBox = new JComboBox<>(months);
        monthComboBox.setSelectedIndex(Calendar.getInstance().get(Calendar.MONTH));

        // ComboBox per selezionare l'anno
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        Integer[] years = new Integer[1026]; // Anni da 1000 a 2025
        for (int i = 0; i < 1026; i++) {
            years[i] = 1000 + i;
        }
        JComboBox<Integer> yearComboBox = new JComboBox<>(years);
        yearComboBox.setSelectedItem(currentYear);

        controlPanel.add(new JLabel("Mese:"));
        controlPanel.add(monthComboBox);
        controlPanel.add(new JLabel("Anno:"));
        controlPanel.add(yearComboBox);

        // Pannello per il calendario
        JPanel calendarPanel = new JPanel();
        calendarPanel.setLayout(new GridLayout(0, 7));

        // Aggiunta dei giorni della settimana
        String[] daysOfWeek = {"Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"};
        for (String day : daysOfWeek) {
            calendarPanel.add(new JLabel(day, SwingConstants.CENTER));
        }

        // Etichetta per mostrare la data selezionata
        JLabel selectedDateLabel = new JLabel("Data selezionata: ----/--/--", SwingConstants.CENTER);

        // Bottone per confermare la data selezionata
        JButton confirmButton = new JButton("Conferma Data");
        confirmButton.setEnabled(false);

        // Funzione per aggiornare il calendario
        final int[] selectedDay = {-1};
        ActionListener updateCalendar = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedMonth = monthComboBox.getSelectedIndex();
                int selectedYear = (Integer) yearComboBox.getSelectedItem();
                Calendar currentDate = Calendar.getInstance();
                currentDate.set(selectedYear, selectedMonth, 1);
                int firstDayOfMonth = currentDate.get(Calendar.DAY_OF_WEEK);
                int daysInMonth = currentDate.getActualMaximum(Calendar.DAY_OF_MONTH);

                calendarPanel.removeAll();
                for (String day : daysOfWeek) {
                    calendarPanel.add(new JLabel(day, SwingConstants.CENTER));
                }

                for (int i = 0; i < firstDayOfMonth - 1; i++) {
                    calendarPanel.add(new JLabel(""));
                }

                for (int day = 1; day <= daysInMonth; day++) {
                    JButton dayButton = new JButton(String.valueOf(day));
                    dayButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            selectedDay[0] = Integer.parseInt(dayButton.getText());
                            String formattedDate = String.format("%02d-%02d-%02d", selectedYear,selectedMonth + 1,selectedDay[0] );
                            selectedDateLabel.setText("Data selezionata: " + formattedDate);
                            confirmButton.setEnabled(true);
                        }
                    });
                    calendarPanel.add(dayButton);
                }

                calendarPanel.revalidate();
                calendarPanel.repaint();
            }
        };

        monthComboBox.addActionListener(updateCalendar);
        yearComboBox.addActionListener(updateCalendar);

        // Azione per il bottone di conferma
        confirmButton.addActionListener(e -> {
            if (selectedDay[0] != -1) {
                finalDate = selectedDateLabel.getText().replace("Data selezionata: ", "");

                frame.dispose();
            }
        });

        // Pannello inferiore
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(selectedDateLabel, BorderLayout.CENTER);
        bottomPanel.add(confirmButton, BorderLayout.SOUTH);

        frame.add(controlPanel, BorderLayout.NORTH);
        frame.add(calendarPanel, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
        updateCalendar.actionPerformed(null);
    }

}