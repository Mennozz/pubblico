import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;

public class create_account extends javax.swing.JFrame {

public create_account(JFrame f)
{

    JFrame frame = new JFrame("Create Account");
    frame.setSize(400, 300);
    frame.setLayout(new BorderLayout());


    GradientPanel panel = new GradientPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));


    JLabel username = new JLabel("Username: ");
    username.setAlignmentX(Component.CENTER_ALIGNMENT);

    JLabel password = new JLabel("Password: ");
    password.setAlignmentX(Component.CENTER_ALIGNMENT);

    JButton login = new JButton("Registrati");
    login.setAlignmentX(Component.CENTER_ALIGNMENT);

    JToggleButton toggleButton = new JToggleButton("👁️");
    toggleButton.setAlignmentX(Component.CENTER_ALIGNMENT);

    JTextField usernameText = new JTextField();
    usernameText.setMaximumSize(new Dimension(300, 30));

    JPasswordField passwordText = new JPasswordField();
    passwordText.setMaximumSize(new Dimension(300, 30));


    panel.add(Box.createVerticalStrut(35));
    panel.add(username);
    panel.add(usernameText);
    panel.add(Box.createVerticalStrut(40));
    panel.add(password);
    panel.add(passwordText);
    panel.add(Box.createVerticalStrut(5));
    panel.add(toggleButton);
    frame.add(login, BorderLayout.SOUTH);
    frame.add(panel, BorderLayout.CENTER);

    toggleButton.addItemListener(new ItemListener() {
        @Override
        public void itemStateChanged(ItemEvent e) {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                // Mostra la password in chiaro
                passwordText.setEchoChar((char) 0); // Caratteri visibili
            } else {
                // Nasconde la password con un asterisco
                passwordText.setEchoChar('•'); // Caratteri mascherati
            }
        }
    });



    login.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            String username = usernameText.getText();
            String password = passwordText.getText();
            if (username != "" && password != "")
            {
                try
                {
                    FileWriter fw = new FileWriter("Login.txt",true);
                    fw.write("\n"+username+"\n"+password+"\n");
                    JOptionPane.showMessageDialog(frame, "Il tuo account è stato creato con successo ;)");
                    fw.close();
                    frame.dispose();
                    new login(frame);
                }
                catch (IOException i)
                {
                    JOptionPane.showMessageDialog(frame, "Errore nella creazione dell'account\nAccount non registrato");
                }
            }
        }
    });

    frame.addWindowListener(new WindowAdapter() {
        @Override
        public void windowClosing(WindowEvent e) {
            // Chiamare dispose() quando la finestra sta per essere chiusa

            frame.dispose();
            f.setVisible(true);

        }
    });



    frame.setSize(500, 300);
    frame.setLocationRelativeTo(null);
    frame.setResizable(false);
    frame.setVisible(true);
}

}

