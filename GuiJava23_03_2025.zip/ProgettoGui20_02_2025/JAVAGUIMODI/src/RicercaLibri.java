import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class RicercaLibri {

    public RicercaLibri() {

        // Crea il frame (finestra)
        JFrame frame = new JFrame("Inserimento del libro");
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());


        // Crea un pannello per contenere i campi di testo e il menù a tendina
        GradientPanel panel = new GradientPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JButton titolo = new JButton("Titolo");
        titolo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titolo.setMaximumSize(new Dimension(350, 40));


        JButton autore = new JButton("Autore");
        autore.setAlignmentX(Component.CENTER_ALIGNMENT);
        autore.setMaximumSize(new Dimension(350, 40));


        JButton casa = new JButton("Casa Editrice");
        casa.setAlignmentX(Component.CENTER_ALIGNMENT);
        casa.setMaximumSize(new Dimension(350, 40));


        JButton anno = new JButton("Anno");
        anno.setAlignmentX(Component.CENTER_ALIGNMENT);
        anno.setMaximumSize(new Dimension(350, 40));


        JButton genere = new JButton("Genere");
        genere.setAlignmentX(Component.CENTER_ALIGNMENT);
        genere.setMaximumSize(new Dimension(350, 40));

        panel.add(Box.createVerticalStrut(15));

        panel.add(titolo);
        panel.add(Box.createVerticalStrut(15));

        panel.add(autore);
        panel.add(Box.createVerticalStrut(15));

        panel.add(casa);
        panel.add(Box.createVerticalStrut(15));

        panel.add(anno);
        panel.add(Box.createVerticalStrut(15));

        panel.add(genere);
        panel.add(Box.createVerticalStrut(15));

        frame.add(panel, BorderLayout.CENTER);

        titolo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci un titolo");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <=4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });
        autore.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci un autore");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <= 4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });
        casa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci una casa editrice");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <= 4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });
        anno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci un anno");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <= 4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });
        genere.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tit = JOptionPane.showInputDialog("Inserisci un genere");
                String libri = null;
                try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
                    String riga;
                    int count = 0;
                    String libro = "";
                    libri = "";
                    while ((riga = file.readLine()) != null) {
                        for (int i = 0; i <= 4; i++) {
                            libro = libro + riga+"\n";
                            riga=file.readLine();
                        }
                        if (libro.contains(tit)) {
                            libri = libri + libro;
                        }
                        libro="";

                    }

                } catch (IOException n) {

                }
                new messaggio(libri);
            }
        });

        frame.setVisible(true);
        frame.setSize(500, 300);
        frame.setLocationRelativeTo(null);
    }

}
