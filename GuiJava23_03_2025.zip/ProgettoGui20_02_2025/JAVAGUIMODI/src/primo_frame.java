import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class primo_frame extends javax.swing.JFrame {

    private JTextField field;
    private JButton bottoneInserisci;
    private JButton bottoneElimina;
    private JButton bottoneRicerca;
    private JButton bottoneModifica;
    private TextAreaPanel area;

    public primo_frame() {
        super("La nostra prima finestra");

        // Impostazioni layout per il JFrame principale
        setLayout(new BorderLayout(10, 10));

        // Creazione dei componenti
        area = new TextAreaPanel();
        bottoneInserisci = new JButton("Inserisci un libro ");
        bottoneElimina = new JButton("Elimina un libro ");
        bottoneRicerca = new JButton("Ricerca un libro ");
        bottoneModifica = new JButton("Modifica un libro ");
        field = new JTextField();

        // Rendere la TextArea non modificabile
        area.setEditable(false);

        // Lettura del file e popolamento dell'area
        leggiFile();

        // Pannello dei bottoni con FlowLayout centrato
        GradientPanel panelB = new GradientPanel();
        panelB.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelB.add(bottoneRicerca);
        panelB.add(bottoneInserisci);
        panelB.add(bottoneElimina);
        panelB.add(bottoneModifica);
        JScrollPane scrollPane = new JScrollPane(area);
        // Aggiunta dell'area di testo sopra i bottoni
        add(scrollPane, BorderLayout.CENTER);

        // Aggiunta del pannello dei bottoni in basso al centro
        add(panelB, BorderLayout.SOUTH);

        // Azioni dei bottoni
        bottoneInserisci.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new inserisciLibro();
                dispose();
            }
        });


        bottoneElimina.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new eliminaFile();
                dispose();
            }
        });
        bottoneRicerca.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            new RicercaLibri();

            }
        });
        bottoneModifica.addActionListener(new ActionListener() {
            @Override public void actionPerformed(ActionEvent e) {
           new ModificaLibro();
            dispose();
        }});

        // Impostazioni finestra
        setSize(800, 500);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Metodo per leggere il file e mostrare il contenuto nell'area
    private void leggiFile() {
        try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
            String riga;
            while ((riga = file.readLine()) != null) {
                area.appenditesto(riga);
                area.appenditesto("\n");
            }
        } catch (IOException e) {
            System.out.println("Errore riscontrato nella lettura di un file");
        }
    }
}
