import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class eliminaFile extends javax.swing.JFrame {
    private JComboBox<String> comboBox;
    private JButton button;
    private ArrayList<String> libreria = new ArrayList<>();

    public eliminaFile() {
        super("Elimina Libro");

        // Impostazione layout della finestra
        setLayout(new BorderLayout(5, 5));  // Margine tra gli oggetti
        setSize(400, 250);  // Ridimensiona la finestra
        setLocationRelativeTo(null);
        setResizable(false);

        // Crea un pannello verticale per gli elementi
        GradientPanel panel = new GradientPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));  // Layout verticale
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);  // Centra il pannello
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));  // Aggiungi margini al pannello

        // Aggiungi etichetta sopra il menù a tendina
        JLabel label = new JLabel("Seleziona il libro da eliminare:");
        label.setAlignmentX(Component.CENTER_ALIGNMENT);  // Centra l'etichetta
        panel.add(label);
        panel.add(Box.createVerticalStrut(30)); // Spazio tra etichetta e comboBox

        // Crea il menù a tendina per la selezione del libro
        comboBox = new JComboBox<>();
        comboBox.setPreferredSize(new Dimension(100, 10));  // Imposta la dimensione compatta

        panel.add(comboBox);
        panel.add(Box.createVerticalStrut(60));  // Spazio tra il comboBox e il bottone

        // Crea il bottone per l'eliminazione
        button = new JButton("Elimina");
        button.setAlignmentX(Component.CENTER_ALIGNMENT);  // Centra il bottone
        panel.add(button);

        // Aggiungi il pannello al centro della finestra
        add(panel, BorderLayout.CENTER);

        // Lettura dei libri dal file "Libreria.txt" e popolamento del comboBox
        try (BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"))) {
            String riga;
            int count = 0;
            String titolo = "";
            while ((riga = file.readLine()) != null) {
                if (count == 0) {
                    titolo = riga;  // La prima riga è il titolo del libro
                    comboBox.addItem(titolo);  // Aggiungi il titolo al comboBox
                }
                // Se la riga è vuota (indicando separazione tra libri), resettiamo count
                if (riga.equals("-------------------")) {
                    count = -1;
                }
                count++;
            }
            file.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Errore durante la lettura del file.");
        }

        // Azione per il bottone di eliminazione
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String titoloSelezionato = (String) comboBox.getSelectedItem();

                if (titoloSelezionato != null) {
                    // Elimina il libro selezionato dal comboBox
                    try {
                        String libriDaSalvare ="";
                        BufferedReader file = new BufferedReader(new FileReader("Libreria.txt"));
                        String riga;
                        boolean eliminato = false;
                        while ((riga = file.readLine()) != null) {
                            // Se la riga contiene il titolo da eliminare, saltalo
                            if (riga.equals(titoloSelezionato)) {
                                eliminato = true;  // Il libro è stato trovato, quindi lo saltiamo
                                // Salta anche le 3 righe successive (autore, casa editrice, anno)
                                file.readLine();
                                file.readLine();
                                file.readLine();
                                file.readLine();
                                file.readLine();

                            } else {
                                // Aggiungi le righe che non sono state eliminate
                                libriDaSalvare=libriDaSalvare+riga+"\n";
                            }
                        }
                        file.close();

                        // Scrive i libri rimanenti nel file
                        FileWriter fw = new FileWriter("Libreria.txt", false);

                            fw.write(libriDaSalvare);

                        fw.close();

                        // Mostra messaggio di successo
                        JOptionPane.showMessageDialog(eliminaFile.this, "Il libro '" + titoloSelezionato + "' è stato eliminato.");
                        dispose();  // Chiudi la finestra di eliminazione
                        new primo_frame();  // Riapri la finestra principale
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(eliminaFile.this, "Errore durante l'eliminazione del libro.");
                    }
                } else {
                    JOptionPane.showMessageDialog(eliminaFile.this, "Devi selezionare un libro da eliminare.");
                }
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new eliminaFile();
    }
}
