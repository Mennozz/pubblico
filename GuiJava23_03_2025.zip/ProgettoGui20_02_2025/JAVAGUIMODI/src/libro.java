public class libro {
    String titolo,autore,Casa,Anno,Genere;
    public libro() {
     String titolo = "",autore="",Casa="",Anno="",Genere="";

 }
 public void SetTitolo (String tito) {
     titolo = tito;
 }
 public void SetAutore(String aut) {
        autore = aut;
 }
 public void SetCasa(String casa) {
        Casa = casa;
 }
 public void SetAnno(String anno) {
        Anno = anno;
 }
 public void SetGenere(String genere) {
        Genere = genere;
 }
 public String GetTitolo() {
        return titolo;
 }
 public String GetAutore() {
        return autore;
 }
 public String GetCasa() {
        return Casa;
 }
 public String GetAnno() {
        return Anno;
 }
 public String GetGenere() {
        return Genere;
 }

}

